#!/usr/bin/bash

#Gathers up files in filelist.txt and figures out the libraries
#Used for IR Response
#Should work on most *Nixs

mkdir `uname -r`
cd `uname -r`
mkdir ./bin
mkdir ./lib
#cp `which hostname` ./bin
for files in `cat ../filelist.txt`
do
   cp `which $files` ./bin
done

ldd bin/* | grep "/lib" | cut -d\> -f2 | cut -d"(" -f 1 | sort |uniq | sed -e "s/\s+//g" | sed -e 's/^/cp /' | sed -e 's/$/ \.\/lib /g' | sh
